$(document).ready(function() {
  $(".message a").click(function() {
    $("form").animate(
      {
        height: "toggle",
        opacity: "toggle"
      },
      "slow"
    );
  });
});
var userlist = {'amit': 12345,"ankit": 12345,"wipro":12345,"devops":12345,"niharika": 12345};
function login() {
	var username = document.querySelector('input[name="username"]').value;
	var password = document.querySelector('input[name="password"]').value;
	if ((Object.keys(userlist).indexOf(username) > -1)&& userlist[username] == password) {
		window.location.href = './order.html';
	}
	else{
		document.querySelectorAll('.error')[0].style.display='block';
		setTimeout(function(){ document.querySelectorAll('.error')[0].style.display='none'; }, 2000);
	}
}