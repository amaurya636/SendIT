# SendIT

SendIT is a courier service that helps users deliver *parcels* to different destinations. SendIT provides courier quotes based on weight categories.

## Features
- Users can create an account and log in.
- Users can create a parcel delivery order.
- Users can change the destination of a parcel delivery order.
- Users can cancel a parcel delivery order.
- Users can see the details of a delivery order.
- Admin can change the status and present location of a parcel delivery order.
- Admin can activate and deactivate users

## Deployment
- UI templates => [GitHub Pages](https://ezrogha.github.io/SendIT/UI/)

## Credit 
- *Kira auf der Heide* for "tilt-shift lens photography of woman holding candy cane-print gift box in a well-lit room" photograph downloaded from unsplash.com
- *Maarten van den Heuvel* for "man in brown jacket beside car" photograph downloaded from unsplash.com
